import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Point
import time
import csv
import math

# -------- CONFIGURATION (YOU MUST UPDATE THIS!) --------
# Use "ros2 topic echo /laser/position" to find these values first.
PIXEL_ZERO = 310.0   # The pixel value when laser is at 0 degrees
PIXEL_45   = 580.0   # The pixel value when laser is at 45 degrees

# Math to convert Pixel -> Degrees for logging
# (This reverses the tangent formula so we can log "Actual Degrees")
SCALE_FACTOR = PIXEL_45 - PIXEL_ZERO

def get_degrees_from_pixel(px):
    if SCALE_FACTOR == 0: return 0
    # Inverse Tangent Calculation
    val = (px - PIXEL_ZERO) / SCALE_FACTOR
    return math.degrees(math.atan(val))

class ExperimentSuite(Node):
    def __init__(self):
        super().__init__('experiment_suite') #inititialize the ROS internals
        
        # Publishers & Subscribers
        self.target_pub = self.create_publisher(Float32, '/servo/set_target_angle', 10) #command output
        self.laser_sub = self.create_subscription(Point, '/laser/position', self.laser_callback, 10) #sensor input
        
        self.current_pixel = PIXEL_ZERO
        self.data_log = [] # Stores [Time, Target_Deg, Actual_Deg, Raw_Pixel]
        self.start_time = time.time()
        
        print(f"   Experiment Suite Ready.")
        print(f"   Calibration: 0°={PIXEL_ZERO}px, 45°={PIXEL_45}px")

    def laser_callback(self, msg): #runs automatically whenever ROS Receives data
        self.current_pixel = msg.x

    def send_target(self, angle_deg): #converts python value --> ros messages & publishes command
        msg = Float32()
        msg.data = float(angle_deg)
        self.target_pub.publish(msg)

    def record_sample(self, target_deg):
        t = time.time() - self.start_time
        actual_deg = get_degrees_from_pixel(self.current_pixel)
        self.data_log.append([t, target_deg, actual_deg, self.current_pixel])
        return actual_deg

    def save_data(self, filename):
        with open(filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Time", "Target_Deg", "Actual_Deg", "Raw_Pixel"])
            writer.writerows(self.data_log)
        print(f"Data saved to {filename}")

    # --- EXPERIMENT 1: HYSTERESIS SWEEP ---
    def run_hysteresis(self):
        print("\n STARTING EXPERIMENT 1: Hysteresis Sweep")
        print("Sequence: 0 -> 45 -> -45 -> 0")
        
        # Step through angles with 1-second pause
        # 0 to 45, then 45 to -45, then -45 to 0
        targets = list(range(0, 46, 2)) + list(range(44, -46, -2)) + list(range(-44, 1, 2))
        
        self.start_time = time.time()
        for deg in targets:
            self.send_target(deg)
            time.sleep(1.0) # Wait for robot to settle
            
            # Take average of 10 samples to reduce noise
            avg_deg = 0
            for _ in range(10):
                avg_deg += self.record_sample(deg)
                time.sleep(0.05)
            print(f"Target: {deg}° | Actual: {avg_deg/10:.2f}°")
            
        self.save_data("exp1_hysteresis.csv")

    # --- EXPERIMENT 2: STEP RESPONSE ---
    def run_step_response(self):
        print("\n STARTING EXPERIMENT 2: Step Response (0 -> 30)")
        self.send_target(0)
        time.sleep(3) # Wait to stabilize at 0
        
        print("JUMPING to 30 degrees...")
        self.start_time = time.time()
        
        # Record at high speed (50Hz) for 5 seconds
        end_time = self.start_time + 5.0
        while time.time() < end_time:
            # First 0.5s: Hold 0. Afterwards: Hold 30.
            target = 0 if (time.time() - self.start_time) < 0.5 else 30
            self.send_target(target)
            self.record_sample(target)
            time.sleep(0.02) # 20ms delay
            
        self.save_data("exp2_step_response.csv")

    # --- EXPERIMENT 3: REPEATABILITY ---
    def run_repeatability(self):
        print("\n STARTING EXPERIMENT 3: Repeatability (20 Loops)")
        print("Loop: 0 -> 30 -> 0")
        
        self.start_time = time.time()
        for i in range(20):
            # Go Out
            self.send_target(30)
            time.sleep(1.5)
            self.record_sample(30)
            
            # Return Home
            self.send_target(0)
            time.sleep(1.5)
            actual = self.record_sample(0)
            print(f"Loop {i+1}/20: Return Error = {actual:.3f}°")
            
        self.save_data("exp3_repeatability.csv")

def main(args=None):
    rclpy.init(args=args)
    node = ExperimentSuite()
    
    # Simple Menu
    print("\nSelect Experiment:")
    print("[1] Hysteresis Loop (S-Curve)")
    print("[2] Step Response (Dynamics)")
    print("[3] Repeatability Test (Statistics)")
    choice = input("Enter number: ")
    
    # RUN THE SELECTED TEST
    try:
        if choice == '1':
            node.run_hysteresis()
        elif choice == '2':
            node.run_step_response()
        elif choice == '3':
            node.run_repeatability()
        else:
            print("Invalid selection.")
    except KeyboardInterrupt:
        print("Stopping...")
    
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()